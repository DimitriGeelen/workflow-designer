// Round-trip smoke test for the AEF workflow designer prototype.
// Usage: npm i @xmldom/xmldom && node roundtrip.js [path-to-html]
// Verifies: seed build → BPMN XML export → parse back → identity preserved.

const fs = require('fs');
const htmlPath = process.argv[2] || __dirname + '/../aef-workflow-designer.html';
const html = fs.readFileSync(htmlPath, 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];

let DOMParser;
try { DOMParser = require('@xmldom/xmldom').DOMParser; }
catch (_) { console.log('SKIP parse leg: npm i @xmldom/xmldom'); }

function stubEl(tag) {
  return {
    tagName: tag, children: [], attributes: {},
    addEventListener() {}, appendChild(c) { this.children.push(c); return c; },
    removeChild() {}, querySelectorAll: () => [],
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    setAttribute(k, v) { this.attributes[k] = v; },
    getAttribute(k) { return this.attributes[k]; },
    innerHTML: '', textContent: '', style: {}, firstChild: null,
  };
}
const documentStub = {
  getElementById: () => stubEl('stub'),
  createElement: t => stubEl(t),
  createElementNS: (_n, t) => stubEl(t),
  createTextNode: t => ({ textContent: t }),
  body: stubEl('body'), addEventListener() {}, querySelectorAll: () => [],
};
const windowStub = { addEventListener() {}, getComputedStyle: () => ({}), DOMParser: DOMParser || function(){ this.parseFromString = () => null; } };

const wrapped = script + `
  return { buildBpmnXml, parseBpmnXml, state, library, activeKey };`;
const fn = new Function('document','window','navigator','alert','prompt','URL','Blob','DOMParser', wrapped);
const r = fn(documentStub, windowStub, { clipboard: { writeText: async () => {} } },
             () => {}, () => null, { createObjectURL: () => '', revokeObjectURL: () => {} },
             function(){}, DOMParser);

let pass = 0, fail = 0;
const check = (name, ok) => { console.log(`  ${ok ? '✓' : '✗'} ${name}`); ok ? pass++ : fail++; };

console.log(`Seed: ${r.state.nodes.length} nodes, ${r.state.edges.length} edges; active=${r.activeKey}`);
const xml = r.buildBpmnXml(r.state);
check('bpmn:definitions present', xml.includes('<bpmn:definitions'));
check('aef:workflowMeta present', xml.includes('aef:workflowMeta'));
check('aef:position present', xml.includes('aef:position'));
check('all nodes exported', (xml.match(/<bpmn:(startEvent|endEvent|serviceTask|userTask|scriptTask|exclusiveGateway|parallelGateway|intermediateThrowEvent|intermediateCatchEvent)\s/g) || []).length === r.state.nodes.length);
check('all edges exported', (xml.match(/<bpmn:sequenceFlow\s/g) || []).length === r.state.edges.length);

if (DOMParser) {
  const p = r.parseBpmnXml(xml);
  check('parse returns workflow', !!p);
  check('node count preserved', p.nodes.length === r.state.nodes.length);
  check('edge count preserved', p.edges.length === r.state.edges.length);
  const orig = new Set(r.state.nodes.map(n => n.uid));
  check('all uids preserved', p.nodes.every(n => orig.has(n.uid)));
  check('edge refs are uids', p.edges.every(e => orig.has(e.source) && orig.has(e.target)));
  const byUid = new Map(r.state.nodes.map(n => [n.uid, n]));
  check('positions preserved', p.nodes.every(n => {
    const o = byUid.get(n.uid);
    return o && Math.abs(n.x - o.x) < 1 && Math.abs(n.y - o.y) < 1;
  }));
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
